/*************************************************
*       The E text editor - 2nd incarnation      *
*************************************************/

/* Written by Philip Hazel, December 1997 */
/* This file last modified: Dec 1997 */

/* This file is specific to the support of NetBSD. It contains
things that have to get imported into the main ehdr.h file
for system-specific reasons. */

/* There aren't any for NetBSD. */

/* End of elocal.netbsd.h */
