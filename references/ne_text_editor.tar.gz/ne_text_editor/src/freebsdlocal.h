/*************************************************
*       The E text editor - 2nd incarnation      *
*************************************************/

/* Written by Richard Brooksby, starting June 1997 */
/* This file last modified: June 1997 */

/* This file is specific to the support of FreeBSD */

#include "sys/fcntl.h"
#include "sys/ioctl.h"
#include "termcap.h"
#include "termios.h"

/* End of freebsdlocal.h */
