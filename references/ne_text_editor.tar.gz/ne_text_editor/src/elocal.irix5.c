/*************************************************
*       The E text editor - 2nd incarnation      *
*************************************************/

/* Copyright (c) University of Cambridge, 1992, 1993 */

/* Written by Philip Hazel, starting November 1991 */
/* This file last modified: March 1994 */

/* This file is specific to the support of IRIX. It contains
functions that are specific to the particular operating system,
or compiler, or whatever. */

#include "ehdr.h"

/* End of elocal.irix5.c */
