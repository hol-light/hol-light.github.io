/*************************************************
*       The E text editor - 2nd incarnation      *
*************************************************/

/* Copyright (c) University of Cambridge, 1992, 1993 */

/* Written by Philip Hazel, starting November 1991 */
/* This file last modified: October 1994 */

/* This file is specific to the support of Ultrix. It contains
things that have to get imported into the main ehdr.h file
for system-specific reasons. */

/* There aren't any for Ultrix.

/* End of elocal.ultrix.h */
