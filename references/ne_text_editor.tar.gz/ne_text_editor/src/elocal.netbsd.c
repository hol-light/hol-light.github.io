/*************************************************
*       The E text editor - 2nd incarnation      *
*************************************************/

/* Written by Philip Hazel, starting December 1997 */
/* This file last modified: December 1997 */

/* This file is specific to the support of NetBSD. It contains
functions that are specific to the particular operating system,
or compiler, or whatever. */

/* There aren't any for NetBSD. */

/* End of elocal.netbsd.c */
