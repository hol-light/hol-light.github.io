/*************************************************
*       The E text editor - 2nd incarnation      *
*************************************************/

/* Written by Richard Brooksby, starting June 1997 */
/* This file last modified: June 1997 */

/* This file is specific to the support of FreeBSD. It contains
things that have to get imported into the main ehdr.h file
for system-specific reasons. */

/* There aren't any for FreeBSD. */

/* End of elocal.freebsd.h */
