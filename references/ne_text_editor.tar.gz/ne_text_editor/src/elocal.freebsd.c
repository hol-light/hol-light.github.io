/*************************************************
*       The E text editor - 2nd incarnation      *
*************************************************/

/* Written by Richard Brooksby, starting June 1997 */
/* This file last modified: June 1997 */

/* This file is specific to the support of FreeBSD. It contains
functions that are specific to the particular operating system,
or compiler, or whatever. */

/* There aren't any for FreeBSD. */

/* End of elocal.freebsd.c */
